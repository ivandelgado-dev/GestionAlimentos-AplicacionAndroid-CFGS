package com.example.ivandelgado_gestionalimentosroom

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class GestionAlimentosApplication : Application()