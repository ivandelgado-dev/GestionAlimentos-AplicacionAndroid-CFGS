package com.example.ivandelgado_gestionalimentosroom.navigation

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.ivandelgado_gestionalimentosroom.componentes.NavigationButton
import com.example.ivandelgado_gestionalimentosroom.screens.ComponenteDetalle
import com.example.ivandelgado_gestionalimentosroom.screens.Formulario
import com.example.ivandelgado_gestionalimentosroom.screens.Inicio
import com.example.ivandelgado_gestionalimentosroom.screens.ListadoDetalle

@Composable
fun AppNavigation(
    modifier: Modifier = Modifier,
    navController: NavHostController = rememberNavController()
) {
    Column(modifier = modifier) {
        NavigationButton(navController)
        NavHost(
            navController = navController,
            startDestination = Routes.Inicio.route,
            modifier = Modifier
        ) {
            composable(Routes.Inicio.route) {
                Inicio()
            }
            composable(
                route = Routes.Formulario.route,
                arguments = listOf(
                    navArgument("componenteId") { 
                        type = NavType.StringType 
                        nullable = true
                        defaultValue = "nuevo"
                    }
                )
            ) { backStackEntry ->
                val componenteId = backStackEntry.arguments?.getString("componenteId")
                Formulario(
                    componenteId = if (componenteId == "nuevo") null else componenteId?.toIntOrNull(),
                    onNavigateBack = { navController.popBackStack() }
                )
            }
            composable(Routes.ListadoDetalle.route) {
                ListadoDetalle(
                    onComponenteClick = { componenteId ->
                        navController.navigate(route = Routes.ComponenteDetalle.createRoute(componenteId))
                    },
                    onAddClick = {
                        navController.navigate(route = Routes.Formulario.createRoute())
                    },
                    onEditClick = { componenteId ->
                        navController.navigate(route = Routes.Formulario.createRoute(componenteId))
                    },
                    onDeleteClick = { componenteId ->
                        // La eliminación se maneja en el ViewModel
                    }
                )
            }
            composable(
                route = Routes.ComponenteDetalle.route,
                arguments = listOf(
                    navArgument("componenteId") { type = NavType.IntType }
                )
            ) { backStackEntry ->
                val componenteId = backStackEntry.arguments?.getInt("componenteId") ?: return@composable
                ComponenteDetalle(
                    componenteId = componenteId,
                    onNavigateBack = { navController.popBackStack() }
                )
            }
        }
    }
}