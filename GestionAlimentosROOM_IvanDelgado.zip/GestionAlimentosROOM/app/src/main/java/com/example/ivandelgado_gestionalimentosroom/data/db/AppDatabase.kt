package com.example.ivandelgado_gestionalimentosroom.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.ivandelgado_gestionalimentosroom.data.dao.ComponenteDietaDao
import com.example.ivandelgado_gestionalimentosroom.data.dao.IngredienteDao
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.Ingrediente

@Database(entities = [ComponenteDieta::class, Ingrediente::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {

    abstract fun componenteDietaDao(): ComponenteDietaDao
    abstract fun ingredienteDao(): IngredienteDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(database: SupportSQLiteDatabase) {
                // Eliminar la tabla si existe
                database.execSQL("DROP TABLE IF EXISTS componentes_dieta")
                
                // Crear la tabla con la estructura correcta
                database.execSQL("""
                    CREATE TABLE IF NOT EXISTS componentes_dieta (
                        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                        nombre TEXT NOT NULL,
                        tipo TEXT NOT NULL,
                        grHC_ini REAL NOT NULL,
                        grLip_ini REAL NOT NULL,
                        grPro_ini REAL NOT NULL
                    )
                """)
            }
        }

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "app_database"
                )
                .addMigrations(MIGRATION_1_2)
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}