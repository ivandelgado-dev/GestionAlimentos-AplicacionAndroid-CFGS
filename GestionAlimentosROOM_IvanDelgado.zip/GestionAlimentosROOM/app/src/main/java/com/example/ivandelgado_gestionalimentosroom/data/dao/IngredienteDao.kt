package com.example.ivandelgado_gestionalimentosroom.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.ivandelgado_gestionalimentosroom.data.modelo.Ingrediente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.IngredienteConComponente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import kotlinx.coroutines.flow.Flow

@Dao
interface IngredienteDao {

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insert(ingrediente: Ingrediente)

    @Update
    suspend fun update(ingrediente: Ingrediente)

    @Delete
    suspend fun delete(ingrediente: Ingrediente)

    @Transaction
    @Query("SELECT * FROM ingredientes")
    fun getAllIngredientes(): Flow<List<IngredienteConComponente>>

    @Transaction
    @Query("SELECT * FROM ingredientes WHERE id = :id")
    fun getIngredienteById(id: Int): Flow<IngredienteConComponente>

    @Transaction
    @Query("SELECT * FROM ingredientes WHERE componenteDietaId = :componenteDietaId")
    fun getIngredientesByComponenteDietaId(componenteDietaId: Int): Flow<List<IngredienteConComponente>>

    @Transaction
    @Query("SELECT * FROM ingredientes WHERE ingredienteId = :ingredienteId")
    fun getIngredientesByIngredienteId(ingredienteId: Int): Flow<List<IngredienteConComponente>>

    @Transaction
    @Query("SELECT * FROM ingredientes WHERE componenteDietaId = :componenteId")
    suspend fun getIngredientesByComponenteDietaIdSync(componenteId: Int): List<IngredienteConComponente>

    @Transaction
    @Query("SELECT cd.* FROM componentes_dieta cd INNER JOIN ingredientes i ON cd.id = i.componenteDietaId WHERE i.ingredienteId = :ingredienteId")
    suspend fun getComponentesQueUsanIngrediente(ingredienteId: Int): List<ComponenteDieta>
}