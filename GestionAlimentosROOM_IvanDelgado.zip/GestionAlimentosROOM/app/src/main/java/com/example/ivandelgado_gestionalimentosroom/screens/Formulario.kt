package com.example.ivandelgado_gestionalimentosroom.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.TipoComponente
import com.example.ivandelgado_gestionalimentosroom.viewmodel.ComponenteDietaViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Formulario(
    componenteId: Int? = null,
    onNavigateBack: () -> Unit,
    viewModel: ComponenteDietaViewModel = hiltViewModel()
) {
    var componenteDieta by remember { mutableStateOf(ComponenteDieta(nombre = "")) }
    var text1 by remember { mutableStateOf("") }
    var text2 by remember { mutableStateOf("") }
    var text3 by remember { mutableStateOf("") }
    var text4 by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedTipo by remember { mutableStateOf(TipoComponente.SIMPLE) }
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Nuevo Componente",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(bottom = 16.dp)
                )

                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = "Información Nutricional",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                        Text(
                            text = "Kcal: ${componenteDieta.calculaKcal()}",
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                OutlinedTextField(
                    value = text1,
                    onValueChange = { newText ->
                        text1 = newText
                        componenteDieta = componenteDieta.copy(nombre = newText)
                    },
                    label = { Text("Nombre del componente") },
                    placeholder = { Text("Introduce el nombre") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                
                Spacer(modifier = Modifier.height(16.dp))
                
                ExposedDropdownMenuBox(
                    expanded = expanded,
                    onExpandedChange = { expanded = !expanded }
                ) {
                    OutlinedTextField(
                        value = selectedTipo.name,
                        onValueChange = { },
                        readOnly = true,
                        label = { Text("Tipo de componente") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false }
                    ) {
                        TipoComponente.values().forEach { tipo ->
                            DropdownMenuItem(
                                text = { Text(text = tipo.name) },
                                onClick = {
                                    selectedTipo = tipo
                                    componenteDieta = componenteDieta.copy(tipo = tipo)
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = text2,
                    onValueChange = { newText ->
                        if (newText.isEmpty() || newText.matches(Regex("^\\d*\\.?\\d*$"))) {
                            text2 = newText
                            componenteDieta = componenteDieta.copy(
                                grPro_ini = newText.toDoubleOrNull() ?: 0.0
                            )
                        }
                    },
                    label = { Text("Proteínas (g/100g)") },
                    placeholder = { Text("0.0") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = text3,
                    onValueChange = { newText ->
                        if (newText.isEmpty() || newText.matches(Regex("^\\d*\\.?\\d*$"))) {
                            text3 = newText
                            componenteDieta = componenteDieta.copy(
                                grHC_ini = newText.toDoubleOrNull() ?: 0.0
                            )
                        }
                    },
                    label = { Text("Carbohidratos (g/100g)") },
                    placeholder = { Text("0.0") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = text4,
                    onValueChange = { newText ->
                        if (newText.isEmpty() || newText.matches(Regex("^\\d*\\.?\\d*$"))) {
                            text4 = newText
                            componenteDieta = componenteDieta.copy(
                                grLip_ini = newText.toDoubleOrNull() ?: 0.0
                            )
                        }
                    },
                    label = { Text("Lípidos (g/100g)") },
                    placeholder = { Text("0.0") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(24.dp))
            }

            // Botón fijo en la parte inferior
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp
            ) {
                Button(
                    onClick = {
                        if (componenteDieta.nombre.isBlank()) {
                            scope.launch {
                                snackbarHostState.showSnackbar("El nombre no puede estar vacío")
                            }
                            return@Button
                        }
                        scope.launch {
                            try {
                                if (componenteId == null) {
                                    viewModel.insert(componenteDieta)
                                } else {
                                    viewModel.update(componenteDieta)
                                }
                                // Limpiar el formulario después de una inserción exitosa
                                componenteDieta = ComponenteDieta(nombre = "")
                                text1 = ""
                                text2 = ""
                                text3 = ""
                                text4 = ""
                                selectedTipo = TipoComponente.SIMPLE
                                snackbarHostState.showSnackbar("Componente guardado correctamente")
                            } catch (e: Exception) {
                                snackbarHostState.showSnackbar("Error al guardar: ${e.message}")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text("Guardar Componente")
                }
            }
        }
    }
}