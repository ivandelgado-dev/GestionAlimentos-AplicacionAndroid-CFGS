package com.example.ivandelgado_gestionalimentosroom.componentes

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.example.ivandelgado_gestionalimentosroom.navigation.Routes

@Composable
fun NavigationButton(navController: NavHostController) {
    Row {
        Button(onClick = { navController.navigate(Routes.Inicio.route) }) {
            Text("Inicio")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Button(onClick = { navController.navigate(Routes.Formulario.route) }) {
            Text("Formulario")
        }
        Spacer(modifier = Modifier.width(8.dp))
        Button(onClick = { navController.navigate(Routes.ListadoDetalle.route) }) {
            Text("Listado")
        }
    }
}