package com.example.ivandelgado_gestionalimentosroom.utils

internal fun Double.format(decimals: Int): String = "%.${decimals}f".format(this) 