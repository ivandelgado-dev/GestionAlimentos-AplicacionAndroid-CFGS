package com.example.ivandelgado_gestionalimentosroom.data.repository

import com.example.ivandelgado_gestionalimentosroom.data.dao.IngredienteDao
import com.example.ivandelgado_gestionalimentosroom.data.modelo.Ingrediente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.IngredienteConComponente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class IngredienteRepository @Inject constructor(
    private val ingredienteDao: IngredienteDao
) {
    suspend fun insert(ingrediente: Ingrediente) {
        ingredienteDao.insert(ingrediente)
    }

    suspend fun update(ingrediente: Ingrediente) {
        ingredienteDao.update(ingrediente)
    }

    suspend fun delete(ingrediente: Ingrediente) {
        ingredienteDao.delete(ingrediente)
    }

    fun getAllIngredientes(): Flow<List<IngredienteConComponente>> {
        return ingredienteDao.getAllIngredientes()
    }

    fun getIngredienteById(id: Int): Flow<IngredienteConComponente> {
        return ingredienteDao.getIngredienteById(id)
    }

    fun getIngredientesByComponenteDietaId(componenteDietaId: Int): Flow<List<IngredienteConComponente>> {
        return ingredienteDao.getIngredientesByComponenteDietaId(componenteDietaId)
    }

    fun getIngredientesByIngredienteId(ingredienteId: Int): Flow<List<IngredienteConComponente>> {
        return ingredienteDao.getIngredientesByIngredienteId(ingredienteId)
    }

    suspend fun getIngredientesByComponenteDietaIdSync(componenteId: Int): List<IngredienteConComponente> {
        return ingredienteDao.getIngredientesByComponenteDietaIdSync(componenteId)
    }

    suspend fun getComponentesQueUsanIngrediente(ingredienteId: Int): List<ComponenteDieta> {
        return ingredienteDao.getComponentesQueUsanIngrediente(ingredienteId)
    }
}