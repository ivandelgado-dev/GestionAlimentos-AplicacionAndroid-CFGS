package com.example.ivandelgado_gestionalimentosroom.ui.theme

import androidx.compose.ui.graphics.Color

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

// Colores personalizados de la aplicación
val Primary = Color(0xFF1976D2)
val PrimaryLight = Color(0xFF63A4FF)
val PrimaryDark = Color(0xFF004BA0)

val Secondary = Color(0xFF26A69A)
val SecondaryLight = Color(0xFF64D8CB)
val SecondaryDark = Color(0xFF00766C)

val Tertiary = Color(0xFF7E57C2)
val TertiaryLight = Color(0xFFB085F5)
val TertiaryDark = Color(0xFF4D2C91)

val Error = Color(0xFFB00020)
val Background = Color(0xFFFAFAFA)
val Surface = Color(0xFFFFFFFF)
val SurfaceVariant = Color(0xFFF5F5F5)

val OnPrimary = Color(0xFFFFFFFF)
val OnSecondary = Color(0xFFFFFFFF)
val OnTertiary = Color(0xFFFFFFFF)
val OnError = Color(0xFFFFFFFF)
val OnBackground = Color(0xFF000000)
val OnSurface = Color(0xFF000000)