package com.example.ivandelgado_gestionalimentosroom.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ivandelgado_gestionalimentosroom.data.modelo.Ingrediente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.IngredienteConComponente
import com.example.ivandelgado_gestionalimentosroom.data.repository.IngredienteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class IngredienteViewModel @Inject constructor(
    private val ingredienteRepository: IngredienteRepository
) : ViewModel() {

    fun insert(ingrediente: Ingrediente) {
        viewModelScope.launch {
            ingredienteRepository.insert(ingrediente)
        }
    }

    fun update(ingrediente: Ingrediente) {
        viewModelScope.launch {
            ingredienteRepository.update(ingrediente)
        }
    }

    fun delete(ingrediente: Ingrediente) {
        viewModelScope.launch {
            ingredienteRepository.delete(ingrediente)
        }
    }

    fun getAllIngredientes(): Flow<List<IngredienteConComponente>> {
        return ingredienteRepository.getAllIngredientes()
    }

    fun getIngredienteById(id: Int): Flow<IngredienteConComponente> {
        return ingredienteRepository.getIngredienteById(id)
    }

    fun getIngredientesByComponenteDietaId(componenteDietaId: Int): Flow<List<IngredienteConComponente>> {
        return ingredienteRepository.getIngredientesByComponenteDietaId(componenteDietaId)
            .distinctUntilChanged()
    }

    fun getIngredientesByIngredienteId(ingredienteId: Int): Flow<List<IngredienteConComponente>> {
        return ingredienteRepository.getIngredientesByIngredienteId(ingredienteId)
            .distinctUntilChanged()
    }

    suspend fun getIngredientesByComponenteDietaIdSync(componenteId: Int): List<IngredienteConComponente> {
        return ingredienteRepository.getIngredientesByComponenteDietaIdSync(componenteId)
    }
}