package com.example.ivandelgado_gestionalimentosroom.data.modelo

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey
import androidx.room.Relation
import java.io.Serializable

@Entity(
    tableName = "ingredientes",
    foreignKeys = [
        ForeignKey(
            entity = ComponenteDieta::class,
            parentColumns = ["id"],
            childColumns = ["componenteDietaId"],
            onDelete = ForeignKey.CASCADE
        ),
        ForeignKey(
            entity = ComponenteDieta::class,
            parentColumns = ["id"],
            childColumns = ["ingredienteId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [
        Index("componenteDietaId"),
        Index("ingredienteId")
    ]
)
data class Ingrediente(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val componenteDietaId: Int,
    val ingredienteId: Int,
    var cantidad: Double = 100.0
) : Serializable

data class IngredienteConComponente(
    @androidx.room.Embedded
    val ingrediente: Ingrediente,
    
    @Relation(
        parentColumn = "ingredienteId",
        entityColumn = "id"
    )
    val componentePrincipal: ComponenteDieta
) {
    fun calculaKcalPor100g(): Double {
        return componentePrincipal.calculaKcal()
    }

    fun calculaKcalTotal(): Double {
        return (calculaKcalPor100g() * ingrediente.cantidad) / 100.0
    }

    fun calculaProteinas(): Double {
        return (componentePrincipal.grPro_ini * ingrediente.cantidad) / 100.0
    }

    fun calculaCarbohidratos(): Double {
        return (componentePrincipal.grHC_ini * ingrediente.cantidad) / 100.0
    }

    fun calculaLipidos(): Double {
        return (componentePrincipal.grLip_ini * ingrediente.cantidad) / 100.0
    }

    fun esCompatible(componenteContenedor: ComponenteDieta): Boolean {
        return componenteContenedor.puedeAgregarIngrediente(componentePrincipal)
    }
}