package com.example.ivandelgado_gestionalimentosroom.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.IngredienteConComponente
import com.example.ivandelgado_gestionalimentosroom.data.repository.ComponenteDietaRepository
import com.example.ivandelgado_gestionalimentosroom.data.repository.IngredienteRepository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ComponenteDietaViewModel @Inject constructor(
    private val componenteDietaRepository: ComponenteDietaRepository,
    private val ingredienteRepository: IngredienteRepository
) : ViewModel() {

    fun insert(componenteDieta: ComponenteDieta) {
        viewModelScope.launch {
            componenteDietaRepository.insert(componenteDieta)
        }
    }

    fun update(componenteDieta: ComponenteDieta) {
        viewModelScope.launch {
            componenteDietaRepository.update(componenteDieta)
        }
    }

    fun delete(componenteDieta: ComponenteDieta) {
        viewModelScope.launch {
            componenteDietaRepository.delete(componenteDieta)
        }
    }

    fun getAllComponentesDieta(): Flow<List<ComponenteDieta>> {
        return componenteDietaRepository.getAllComponentesDieta()
    }

    fun getComponenteDietaById(id: Int): Flow<ComponenteDieta> {
        return componenteDietaRepository.getComponenteDietaById(id)
    }

    fun getComponenteDietaByNombre(nombre: String): Flow<List<ComponenteDieta>> {
        return componenteDietaRepository.getComponenteDietaByNombre(nombre)
    }

    data class ValoresNutricionales(
        val kcal: Double = 0.0,
        val proteinas: Double = 0.0,
        val carbohidratos: Double = 0.0,
        val lipidos: Double = 0.0
    )

    private suspend fun calcularValoresNutricionales(
        componente: ComponenteDieta,
        ingredientes: List<IngredienteConComponente>,
        caminoActual: MutableSet<Int> = mutableSetOf()
    ): ValoresNutricionales {
        // Detectar ciclos infinitos
        if (caminoActual.contains(componente.id)) {
            return ValoresNutricionales()
        }
        
        // Añadir el componente actual al camino
        caminoActual.add(componente.id)

        // Valores base del componente
        var kcalTotal = componente.calculaKcal()
        var proteinasTotal = componente.grPro_ini
        var carbohidratosTotal = componente.grHC_ini
        var lipidosTotal = componente.grLip_ini

        // Calcular valores de los ingredientes
        for (ingrediente in ingredientes) {
            // Obtener los ingredientes del componente actual
            val ingredientesAnidados = ingredienteRepository.getIngredientesByComponenteDietaIdSync(ingrediente.componentePrincipal.id)
            
            // Crear una nueva copia del camino para cada rama de recursión
            val nuevoCamino = caminoActual.toMutableSet()
            
            // Calcular valores nutricionales del ingrediente recursivamente
            val valoresIngrediente = calcularValoresNutricionales(
                ingrediente.componentePrincipal,
                ingredientesAnidados,
                nuevoCamino
            )

            // Aplicar la proporción según la cantidad del ingrediente
            val factor = ingrediente.ingrediente.cantidad / 100.0
            kcalTotal += valoresIngrediente.kcal * factor
            proteinasTotal += valoresIngrediente.proteinas * factor
            carbohidratosTotal += valoresIngrediente.carbohidratos * factor
            lipidosTotal += valoresIngrediente.lipidos * factor
        }

        // Remover el componente actual del camino antes de retornar
        caminoActual.remove(componente.id)

        return ValoresNutricionales(
            kcal = kcalTotal,
            proteinas = proteinasTotal,
            carbohidratos = carbohidratosTotal,
            lipidos = lipidosTotal
        )
    }

    fun calculaKcalTotal(componente: ComponenteDieta, ingredientes: List<IngredienteConComponente>): Flow<Double> {
        return flow {
            val valores = calcularValoresNutricionales(componente, ingredientes)
            emit(valores.kcal)
        }.flowOn(Dispatchers.IO)
    }

    fun calculaProteinasTotal(componente: ComponenteDieta, ingredientes: List<IngredienteConComponente>): Flow<Double> {
        return flow {
            val valores = calcularValoresNutricionales(componente, ingredientes)
            emit(valores.proteinas)
        }.flowOn(Dispatchers.IO)
    }

    fun calculaCarbohidratosTotal(componente: ComponenteDieta, ingredientes: List<IngredienteConComponente>): Flow<Double> {
        return flow {
            val valores = calcularValoresNutricionales(componente, ingredientes)
            emit(valores.carbohidratos)
        }.flowOn(Dispatchers.IO)
    }

    fun calculaLipidosTotal(componente: ComponenteDieta, ingredientes: List<IngredienteConComponente>): Flow<Double> {
        return flow {
            val valores = calcularValoresNutricionales(componente, ingredientes)
            emit(valores.lipidos)
        }.flowOn(Dispatchers.IO)
    }
}