package com.example.ivandelgado_gestionalimentosroom.screens

import androidx.compose.animation.*
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.TipoComponente
import com.example.ivandelgado_gestionalimentosroom.viewmodel.ComponenteDietaViewModel
import com.example.ivandelgado_gestionalimentosroom.viewmodel.IngredienteViewModel
import com.example.ivandelgado_gestionalimentosroom.utils.format
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class, ExperimentalAnimationApi::class, ExperimentalFoundationApi::class)
@Composable
fun ListadoDetalle(
    onComponenteClick: (Int) -> Unit,
    onAddClick: () -> Unit,
    onEditClick: (Int) -> Unit,
    onDeleteClick: (Int) -> Unit,
    viewModel: ComponenteDietaViewModel = hiltViewModel(),
    ingredienteViewModel: IngredienteViewModel = hiltViewModel()
) {
    val componentesDieta by viewModel.getAllComponentesDieta()
        .collectAsState(initial = emptyList())
    
    var showDeleteConfirmDialog by remember { mutableStateOf<ComponenteDieta?>(null) }
    var showEditDialog by remember { mutableStateOf<ComponenteDieta?>(null) }
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    
    fun filtrarComponentes(componentes: List<ComponenteDieta>, searchQuery: String, selectedTipo: TipoComponente?): List<ComponenteDieta> {
        return componentes.filter { componente ->
            val matchesSearch = componente.nombre.contains(searchQuery, ignoreCase = true)
            val matchesType = selectedTipo == null || componente.tipo == selectedTipo
            matchesSearch && matchesType
        }
    }

    var searchQuery by remember { mutableStateOf("") }
    var selectedTipo by remember { mutableStateOf<TipoComponente?>(null) }
    
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddClick,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(Icons.Default.Add, "Añadir componente")
            }
        },
        modifier = Modifier.fillMaxSize()
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            // Encabezado con contador
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Listado de Componentes",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
            }
            
            // Barra de búsqueda
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                label = { Text("Buscar componente") },
                leadingIcon = { Icon(Icons.Default.Search, "Buscar") },
                trailingIcon = if (searchQuery.isNotEmpty()) {
                    {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(Icons.Default.Clear, "Limpiar búsqueda")
                        }
                    }
                } else null,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp)
            )
            
            // Filtro por tipo
            ScrollableTabRow(
                selectedTabIndex = TipoComponente.values().indexOf(selectedTipo) + 1,
                modifier = Modifier.padding(vertical = 8.dp),
                edgePadding = 0.dp
            ) {
                Tab(
                    selected = selectedTipo == null,
                    onClick = { selectedTipo = null }
                ) {
                    Text(
                        text = "Todos",
                        modifier = Modifier.padding(8.dp)
                    )
                }
                TipoComponente.values().forEach { tipo ->
                    Tab(
                        selected = selectedTipo == tipo,
                        onClick = { selectedTipo = tipo }
                    ) {
                        Text(
                            text = tipo.name,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }

            val filteredComponentes = filtrarComponentes(componentesDieta, searchQuery, selectedTipo)

            AnimatedVisibility(
                visible = filteredComponentes.isEmpty(),
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (searchQuery.isEmpty() && selectedTipo == null)
                            "No hay componentes registrados"
                        else
                            "No se encontraron componentes con los filtros aplicados",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(
                    items = filteredComponentes,
                    key = { it.id }
                ) { componente ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .animateItemPlacement()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable { onComponenteClick(componente.id) }
                            ) {
                                Text(
                                    text = componente.nombre,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "Tipo: ${componente.tipo}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                val ingredientes by ingredienteViewModel.getIngredientesByComponenteDietaId(componente.id)
                                    .collectAsState(initial = emptyList())
                                val kcalTotal by viewModel.calculaKcalTotal(componente, ingredientes)
                                    .collectAsState(initial = componente.calculaKcal())
                                Text(
                                    text = "Kcal totales: ${kcalTotal.format(1)}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                            Row {
                                IconButton(onClick = { showEditDialog = componente }) {
                                    Icon(
                                        Icons.Default.Edit,
                                        contentDescription = "Editar",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                                IconButton(onClick = { showDeleteConfirmDialog = componente }) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Eliminar",
                                        tint = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Diálogo de edición
    showEditDialog?.let { componente ->
        var nombre by remember { mutableStateOf(componente.nombre) }
        var tipo by remember { mutableStateOf(componente.tipo) }
        var proteinas by remember { mutableStateOf(componente.grPro_ini.toString()) }
        var carbohidratos by remember { mutableStateOf(componente.grHC_ini.toString()) }
        var lipidos by remember { mutableStateOf(componente.grLip_ini.toString()) }
        var expanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showEditDialog = null },
            title = { Text("Editar Componente") },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 8.dp)
                ) {
                    OutlinedTextField(
                        value = nombre,
                        onValueChange = { nombre = it },
                        label = { Text("Nombre") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        singleLine = true
                    )

                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = tipo.name,
                            onValueChange = { },
                            readOnly = true,
                            label = { Text("Tipo") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            TipoComponente.values().forEach { tipoComponente ->
                                DropdownMenuItem(
                                    text = { Text(tipoComponente.name) },
                                    onClick = {
                                        tipo = tipoComponente
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = proteinas,
                        onValueChange = { newValue ->
                            if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                                proteinas = newValue
                            }
                        },
                        label = { Text("Proteínas (g/100g)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = carbohidratos,
                        onValueChange = { newValue ->
                            if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                                carbohidratos = newValue
                            }
                        },
                        label = { Text("Carbohidratos (g/100g)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        singleLine = true
                    )

                    OutlinedTextField(
                        value = lipidos,
                        onValueChange = { newValue ->
                            if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                                lipidos = newValue
                            }
                        },
                        label = { Text("Lípidos (g/100g)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Mostrar información nutricional calculada
                    val kcal = (proteinas.toDoubleOrNull() ?: 0.0) * 4.0 +
                              (carbohidratos.toDoubleOrNull() ?: 0.0) * 4.0 +
                              (lipidos.toDoubleOrNull() ?: 0.0) * 9.0

                    Text(
                        text = "Kcal totales: ${"%.1f".format(kcal)}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val componenteActualizado = componente.copy(
                            nombre = nombre,
                            tipo = tipo,
                            grPro_ini = proteinas.toDoubleOrNull() ?: 0.0,
                            grHC_ini = carbohidratos.toDoubleOrNull() ?: 0.0,
                            grLip_ini = lipidos.toDoubleOrNull() ?: 0.0
                        )
                        scope.launch {
                            try {
                                viewModel.update(componenteActualizado)
                                snackbarHostState.showSnackbar("Componente actualizado correctamente")
                                showEditDialog = null
                            } catch (e: Exception) {
                                snackbarHostState.showSnackbar("Error al actualizar: ${e.message}")
                            }
                        }
                    }
                ) {
                    Text("Guardar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = null }) {
                    Text("Cancelar")
                }
            }
        )
    }

    // Diálogo de confirmación para eliminar
    showDeleteConfirmDialog?.let { componente ->
        AlertDialog(
            onDismissRequest = { showDeleteConfirmDialog = null },
            title = { Text("Confirmar eliminación") },
            text = { 
                Column {
                    Text("¿Estás seguro de que deseas eliminar el componente '${componente.nombre}'?")
                    Text(
                        text = "Esta acción no se puede deshacer.",
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            viewModel.delete(componente)
                            snackbarHostState.showSnackbar(
                                message = "Componente eliminado correctamente",
                                duration = SnackbarDuration.Short
                            )
                        }
                        showDeleteConfirmDialog = null
                        onDeleteClick(componente.id)
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Eliminar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirmDialog = null }) {
                    Text("Cancelar")
                }
            }
        )
    }
}

@Composable
private fun ComponenteItem(
    componente: ComponenteDieta,
    onClick: () -> Unit,
    viewModel: ComponenteDietaViewModel = hiltViewModel(),
    ingredienteViewModel: IngredienteViewModel = hiltViewModel()
) {
    ElevatedCard(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth()
        ) {
            Text(
                text = componente.nombre,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "Tipo: ${componente.tipo}",
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            val ingredientes by ingredienteViewModel.getIngredientesByComponenteDietaId(componente.id)
                .collectAsState(initial = emptyList())
            val kcalTotal by viewModel.calculaKcalTotal(componente, ingredientes)
                .collectAsState(initial = componente.calculaKcal())
            Text(
                text = "Kcal totales: ${kcalTotal.format(1)}",
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}