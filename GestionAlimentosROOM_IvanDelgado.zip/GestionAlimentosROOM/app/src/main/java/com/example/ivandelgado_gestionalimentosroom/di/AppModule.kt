package com.example.ivandelgado_gestionalimentosroom.di

import android.content.Context
import com.example.ivandelgado_gestionalimentosroom.data.dao.ComponenteDietaDao
import com.example.ivandelgado_gestionalimentosroom.data.dao.IngredienteDao
import com.example.ivandelgado_gestionalimentosroom.data.db.AppDatabase
import com.example.ivandelgado_gestionalimentosroom.data.repository.ComponenteDietaRepository
import com.example.ivandelgado_gestionalimentosroom.data.repository.IngredienteRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Singleton
    @Provides
    fun provideAppDatabase(@ApplicationContext context: Context): AppDatabase {
        return AppDatabase.getDatabase(context)
    }

    @Provides
    fun provideComponenteDietaDao(appDatabase: AppDatabase): ComponenteDietaDao {
        return appDatabase.componenteDietaDao()
    }

    @Provides
    fun provideIngredienteDao(appDatabase: AppDatabase): IngredienteDao {
        return appDatabase.ingredienteDao()
    }

    @Provides
    fun provideComponenteDietaRepository(componenteDietaDao: ComponenteDietaDao): ComponenteDietaRepository {
        return ComponenteDietaRepository(componenteDietaDao)
    }

    @Provides
    fun provideIngredienteRepository(ingredienteDao: IngredienteDao): IngredienteRepository {
        return IngredienteRepository(ingredienteDao)
    }
}