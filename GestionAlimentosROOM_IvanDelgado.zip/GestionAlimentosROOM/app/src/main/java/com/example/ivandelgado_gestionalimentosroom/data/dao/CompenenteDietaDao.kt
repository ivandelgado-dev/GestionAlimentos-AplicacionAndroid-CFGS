package com.example.ivandelgado_gestionalimentosroom.data.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import kotlinx.coroutines.flow.Flow

@Dao
interface ComponenteDietaDao {
    @Insert
    suspend fun insert(componenteDieta: ComponenteDieta)

    @Update
    suspend fun update(componenteDieta: ComponenteDieta)

    @Delete
    suspend fun delete(componenteDieta: ComponenteDieta)

    @Query("SELECT * FROM componentes_dieta")
    fun getAllComponentesDieta(): Flow<List<ComponenteDieta>>

    @Query("SELECT * FROM componentes_dieta WHERE id = :id")
    fun getComponenteDietaById(id: Int): Flow<ComponenteDieta>

    @Query("SELECT * FROM componentes_dieta WHERE nombre LIKE '%' || :nombre || '%'")
    fun getComponenteDietaByNombre(nombre: String): Flow<List<ComponenteDieta>>
}