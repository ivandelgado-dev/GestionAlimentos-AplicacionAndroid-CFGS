package com.example.ivandelgado_gestionalimentosroom.data.modelo

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.io.Serializable

enum class TipoComponente {
    SIMPLE,      // Nivel 1: Componentes básicos (ej: manzana, arroz)
    PROCESADO,   // Nivel 2: Alimentos procesados (ej: pan, yogur)
    RECETA,      // Nivel 3: Combinación de simples y procesados
    MENU,        // Nivel 4: Conjunto de recetas y/o alimentos
    DIETA;       // Nivel 5: Plan completo

    fun getNivel(): Int = when (this) {
        SIMPLE -> 1
        PROCESADO -> 2
        RECETA -> 3
        MENU -> 4
        DIETA -> 5
    }
}

@Entity(tableName = "componentes_dieta")
data class ComponenteDieta(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    var nombre: String,
    var tipo: TipoComponente = TipoComponente.SIMPLE,
    var grHC_ini: Double = 0.0,
    var grLip_ini: Double = 0.0,
    var grPro_ini: Double = 0.0
) : Serializable {

    fun calculaKcal(): Double = (grPro_ini * 4.0) + (grHC_ini * 4.0) + (grLip_ini * 9.0)

    fun puedeAgregarIngrediente(otroComponente: ComponenteDieta): Boolean = when (tipo) {
        TipoComponente.SIMPLE, TipoComponente.PROCESADO -> false
        TipoComponente.RECETA -> otroComponente.tipo.getNivel() <= 2
        TipoComponente.MENU -> otroComponente.tipo.getNivel() <= 3
        TipoComponente.DIETA -> otroComponente.tipo.getNivel() <= 4
    }

    fun validarTipoYContenido(ingredientes: List<IngredienteConComponente>): Boolean = when (tipo) {
        TipoComponente.SIMPLE, TipoComponente.PROCESADO -> ingredientes.isEmpty()
        TipoComponente.RECETA -> ingredientes.all { it.componentePrincipal.tipo.getNivel() <= 2 }
        TipoComponente.MENU -> ingredientes.all { it.componentePrincipal.tipo.getNivel() <= 3 }
        TipoComponente.DIETA -> ingredientes.all { it.componentePrincipal.tipo.getNivel() <= 4 }
    }
}