package com.example.ivandelgado_gestionalimentosroom.data.repository

import com.example.ivandelgado_gestionalimentosroom.data.dao.ComponenteDietaDao
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class ComponenteDietaRepository @Inject constructor(
    private val componenteDietaDao: ComponenteDietaDao
) {
    suspend fun insert(componenteDieta: ComponenteDieta) {
        componenteDietaDao.insert(componenteDieta)
    }

    suspend fun update(componenteDieta: ComponenteDieta) {
        componenteDietaDao.update(componenteDieta)
    }

    suspend fun delete(componenteDieta: ComponenteDieta) {
        componenteDietaDao.delete(componenteDieta)
    }

    fun getAllComponentesDieta(): Flow<List<ComponenteDieta>> {
        return componenteDietaDao.getAllComponentesDieta()
    }

    fun getComponenteDietaById(id: Int): Flow<ComponenteDieta> {
        return componenteDietaDao.getComponenteDietaById(id)
    }

    fun getComponenteDietaByNombre(nombre: String): Flow<List<ComponenteDieta>> {
        return componenteDietaDao.getComponenteDietaByNombre(nombre)
    }
}