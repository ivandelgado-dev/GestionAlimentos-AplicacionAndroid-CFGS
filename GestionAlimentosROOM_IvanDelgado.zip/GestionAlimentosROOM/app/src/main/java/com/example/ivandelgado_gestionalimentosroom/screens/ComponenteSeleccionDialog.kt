package com.example.ivandelgado_gestionalimentosroom.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.TipoComponente

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComponenteSeleccionDialog(
    componentes: List<ComponenteDieta>,
    onComponenteSelected: (ComponenteDieta) -> Unit,
    onDismiss: () -> Unit,
    showEmptyMessage: Boolean = false
) {
    var searchQuery by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }
    var selectedTipo: TipoComponente? by remember { mutableStateOf(null) }

    // Log para depuración
    LaunchedEffect(componentes) {
        println("ComponenteSeleccionDialog - Componentes recibidos: ${componentes.size}")
        componentes.forEach { 
            println("Componente: ${it.nombre} (${it.tipo})")
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (showEmptyMessage) "No hay componentes disponibles" else "Seleccionar Componente") },
        text = {
            Column {
                if (showEmptyMessage) {
                    Text(
                        text = "No hay componentes que puedan ser añadidos como ingredientes a este componente. " +
                              "Esto puede deberse a restricciones en la jerarquía de componentes.",
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                } else {
                    // Barra de búsqueda
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        label = { Text("Buscar") },
                        leadingIcon = { Icon(Icons.Default.Search, "Buscar") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )

                    // Selector de tipo
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = selectedTipo?.name ?: "Todos los tipos",
                            onValueChange = { },
                            readOnly = true,
                            label = { Text("Tipo de componente") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                                .padding(bottom = 8.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Todos los tipos") },
                                onClick = {
                                    selectedTipo = null
                                    expanded = false
                                }
                            )
                            // Obtener tipos únicos de los componentes disponibles
                            componentes.map { it.tipo }.distinct().forEach { tipo ->
                                DropdownMenuItem(
                                    text = { Text(tipo.name) },
                                    onClick = {
                                        selectedTipo = tipo
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Lista filtrada
                    val filteredComponentes = componentes.filter { componente ->
                        val matchesSearch = componente.nombre.contains(searchQuery, ignoreCase = true)
                        val matchesType = selectedTipo == null || componente.tipo == selectedTipo
                        matchesSearch && matchesType
                    }

                    if (filteredComponentes.isEmpty()) {
                        Text(
                            text = "No se encontraron componentes",
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            textAlign = TextAlign.Center,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    } else {
                        LazyColumn(
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filteredComponentes) { componente ->
                                ListItem(
                                    headlineContent = { Text(componente.nombre) },
                                    supportingContent = { Text("Tipo: ${componente.tipo}") },
                                    modifier = Modifier
                                        .clickable { onComponenteSelected(componente) }
                                        .fillMaxWidth()
                                )
                                Divider()
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
} 