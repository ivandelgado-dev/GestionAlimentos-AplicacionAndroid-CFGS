package com.example.ivandelgado_gestionalimentosroom.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ivandelgado_gestionalimentosroom.R

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Inicio() {
    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Título
            Text(
                text = "Gestión de Alimentos",
                fontSize = 32.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(vertical = 24.dp)
            )

            // Descripción del proyecto
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Sobre el Proyecto",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Esta aplicación permite gestionar componentes dietéticos e ingredientes " +
                              "de manera jerárquica, facilitando el seguimiento nutricional y la " +
                              "planificación de dietas.",
                        fontSize = 16.sp,
                        lineHeight = 24.sp
                    )
                }
            }

            // Características principales
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Características",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    // Lista de características
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CaracteristicaItem("Gestión de componentes simples y procesados")
                        CaracteristicaItem("Creación de recetas y menús")
                        CaracteristicaItem("Cálculo automático de valores nutricionales")
                        CaracteristicaItem("Organización jerárquica de componentes")
                        CaracteristicaItem("Búsqueda y filtrado avanzado")
                    }
                }
            }

            // Jerarquía de componentes
            ElevatedCard(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp)
                ) {
                    Text(
                        text = "Jerarquía de Componentes",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    
                    Column(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        NivelJerarquiaItem(
                            nivel = "Nivel 1: SIMPLE",
                            descripcion = "Componentes básicos como frutas, verduras, etc."
                        )
                        NivelJerarquiaItem(
                            nivel = "Nivel 2: PROCESADO",
                            descripcion = "Alimentos procesados como pan, yogur, etc."
                        )
                        NivelJerarquiaItem(
                            nivel = "Nivel 3: RECETA",
                            descripcion = "Combinación de componentes simples y procesados"
                        )
                        NivelJerarquiaItem(
                            nivel = "Nivel 4: MENU",
                            descripcion = "Conjunto de recetas y/o alimentos"
                        )
                        NivelJerarquiaItem(
                            nivel = "Nivel 5: DIETA",
                            descripcion = "Plan completo que puede incluir todos los niveles anteriores"
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CaracteristicaItem(texto: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small
    ) {
        Text(
            text = "• $texto",
            modifier = Modifier.padding(8.dp),
            fontSize = 16.sp
        )
    }
}

@Composable
fun NivelJerarquiaItem(nivel: String, descripcion: String) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surfaceVariant,
        shape = MaterialTheme.shapes.small
    ) {
        Column(
            modifier = Modifier.padding(8.dp)
        ) {
            Text(
                text = nivel,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Text(
                text = descripcion,
                fontSize = 14.sp
            )
        }
    }
}