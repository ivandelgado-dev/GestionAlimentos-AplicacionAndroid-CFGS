package com.example.ivandelgado_gestionalimentosroom.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.example.ivandelgado_gestionalimentosroom.data.modelo.ComponenteDieta
import com.example.ivandelgado_gestionalimentosroom.data.modelo.Ingrediente
import com.example.ivandelgado_gestionalimentosroom.data.modelo.IngredienteConComponente
import com.example.ivandelgado_gestionalimentosroom.viewmodel.ComponenteDietaViewModel
import com.example.ivandelgado_gestionalimentosroom.viewmodel.IngredienteViewModel
import com.example.ivandelgado_gestionalimentosroom.utils.format

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComponenteDetalle(
    componenteId: Int,
    onNavigateBack: () -> Unit,
    componenteDietaViewModel: ComponenteDietaViewModel = hiltViewModel(),
    ingredienteViewModel: IngredienteViewModel = hiltViewModel()
) {
    val componente by componenteDietaViewModel.getComponenteDietaById(componenteId)
        .collectAsState(initial = null)
    val ingredientes by ingredienteViewModel.getIngredientesByComponenteDietaId(componenteId)
        .collectAsState(initial = emptyList())
    
    var showAddIngredientDialog by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }
    
    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        floatingActionButton = {
            FloatingActionButton(onClick = { showAddIngredientDialog = true }) {
                Icon(Icons.Default.Add, "Añadir ingrediente")
            }
        }
    ) { padding ->
        if (componente == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator()
            }
        } else {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(16.dp)
            ) {
                // Información del componente
                ElevatedCard(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth()
                    ) {
                        Text(
                            text = componente!!.nombre,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Tipo: ${componente!!.tipo}")
                        Text(
                            text = "Valores nutricionales base:",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        Text("Proteínas: ${componente!!.grPro_ini}g")
                        Text("Carbohidratos: ${componente!!.grHC_ini}g")
                        Text("Lípidos: ${componente!!.grLip_ini}g")
                        Text("Kcal: ${componente!!.calculaKcal()}")

                        Text(
                            text = "Valores nutricionales totales (con ingredientes):",
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                        val proteinasTotal by componenteDietaViewModel.calculaProteinasTotal(componente!!, ingredientes)
                            .collectAsState(initial = 0.0)
                        val carbohidratosTotal by componenteDietaViewModel.calculaCarbohidratosTotal(componente!!, ingredientes)
                            .collectAsState(initial = 0.0)
                        val lipidosTotal by componenteDietaViewModel.calculaLipidosTotal(componente!!, ingredientes)
                            .collectAsState(initial = 0.0)
                        val kcalTotal by componenteDietaViewModel.calculaKcalTotal(componente!!, ingredientes)
                            .collectAsState(initial = 0.0)
                            
                        Text("Proteínas: ${proteinasTotal.format(1)}g")
                        Text("Carbohidratos: ${carbohidratosTotal.format(1)}g")
                        Text("Lípidos: ${lipidosTotal.format(1)}g")
                        Text(
                            text = "Kcal totales: ${kcalTotal.format(1)}",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Lista de ingredientes
                Text(
                    text = "Ingredientes",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                if (ingredientes.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No hay ingredientes añadidos",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(ingredientes) { ingrediente ->
                            IngredienteItem(
                                ingrediente = ingrediente,
                                onDelete = {
                                    ingredienteViewModel.delete(ingrediente.ingrediente)
                                },
                                componenteDietaViewModel = componenteDietaViewModel,
                                ingredienteViewModel = ingredienteViewModel
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddIngredientDialog) {
        AddIngredientDialog(
            componenteId = componenteId,
            onDismiss = { showAddIngredientDialog = false },
            onIngredientAdded = { ingrediente ->
                ingredienteViewModel.insert(ingrediente)
                showAddIngredientDialog = false
            },
            componenteDietaViewModel = componenteDietaViewModel
        )
    }
}

@Composable
fun IngredienteItem(
    ingrediente: IngredienteConComponente,
    onDelete: () -> Unit,
    componenteDietaViewModel: ComponenteDietaViewModel = hiltViewModel(),
    ingredienteViewModel: IngredienteViewModel = hiltViewModel()
) {
    val ingredientesAnidados by ingredienteViewModel.getIngredientesByComponenteDietaId(ingrediente.componentePrincipal.id)
        .collectAsState(initial = emptyList())
    
    val kcalTotal by componenteDietaViewModel.calculaKcalTotal(ingrediente.componentePrincipal, ingredientesAnidados)
        .collectAsState(initial = ingrediente.componentePrincipal.calculaKcal())

    Card(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = ingrediente.componentePrincipal.nombre,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Cantidad: ${ingrediente.ingrediente.cantidad}g",
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = "Kcal totales: ${(kcalTotal * ingrediente.ingrediente.cantidad / 100.0).format(1)}",
                    color = MaterialTheme.colorScheme.primary
                )
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, "Eliminar ingrediente")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddIngredientDialog(
    componenteId: Int,
    onDismiss: () -> Unit,
    onIngredientAdded: (Ingrediente) -> Unit,
    componenteDietaViewModel: ComponenteDietaViewModel = hiltViewModel()
) {
    var cantidad by remember { mutableStateOf("") }
    var selectedComponente by remember { mutableStateOf<ComponenteDieta?>(null) }
    var showError by remember { mutableStateOf<String?>(null) }
    var expanded by remember { mutableStateOf(false) }
    
    // Obtener el componente actual
    val componenteActual by componenteDietaViewModel.getComponenteDietaById(componenteId)
        .collectAsState(initial = null)
    
    // Obtener la lista de componentes disponibles
    val componentesDisponibles by componenteDietaViewModel.getAllComponentesDieta()
        .collectAsState(initial = emptyList())
    
    // Filtrar componentes según la jerarquía y excluir el componente actual
    val componentesFiltrados = componentesDisponibles.filter { componente ->
        // No incluir el componente actual
        if (componente.id == componenteId) return@filter false
        
        // Verificar si el componente actual puede contener este componente
        componenteActual?.puedeAgregarIngrediente(componente) ?: false
    }

    // Log para depuración
    LaunchedEffect(componentesDisponibles, componenteActual) {
        println("Componente actual: ${componenteActual?.nombre} (${componenteActual?.tipo})")
        println("Componentes disponibles: ${componentesDisponibles.size}")
        println("Componentes filtrados: ${componentesFiltrados.size}")
        componentesFiltrados.forEach {
            println("Componente filtrado: ${it.nombre} (${it.tipo})")
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Añadir Ingrediente") },
        text = {
            Column {
                if (showError != null) {
                    Text(
                        text = showError!!,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }

                if (componentesFiltrados.isEmpty()) {
                    Text(
                        text = "No hay componentes disponibles que puedan ser añadidos como ingredientes. " +
                              "Debes crear primero componentes de menor jerarquía.",
                        modifier = Modifier.padding(bottom = 16.dp),
                        color = MaterialTheme.colorScheme.error
                    )
                } else {
                    // Selector de componente con dropdown
                    ExposedDropdownMenuBox(
                        expanded = expanded,
                        onExpandedChange = { expanded = !expanded }
                    ) {
                        OutlinedTextField(
                            value = selectedComponente?.nombre ?: "",
                            onValueChange = { },
                            readOnly = true,
                            label = { Text("Seleccionar componente") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = expanded,
                            onDismissRequest = { expanded = false }
                        ) {
                            componentesFiltrados.forEach { componente ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(componente.nombre)
                                            Text(
                                                text = "Tipo: ${componente.tipo}",
                                                style = MaterialTheme.typography.bodySmall,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    },
                                    onClick = {
                                        selectedComponente = componente
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                if (selectedComponente != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Tipo: ${selectedComponente!!.tipo}")
                    Text("Proteínas: ${selectedComponente!!.grPro_ini}g")
                    Text("Carbohidratos: ${selectedComponente!!.grHC_ini}g")
                    Text("Lípidos: ${selectedComponente!!.grLip_ini}g")
                    Text("Kcal/100g: ${selectedComponente!!.calculaKcal()}")
                }

                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = cantidad,
                    onValueChange = { newValue ->
                        if (newValue.isEmpty() || newValue.matches(Regex("^\\d*\\.?\\d*$"))) {
                            cantidad = newValue
                        }
                    },
                    label = { Text("Cantidad (g)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (selectedComponente != null && cantidad.isNotEmpty()) {
                    val cantidadNum = cantidad.toDoubleOrNull() ?: 0.0
                    Text(
                        text = "Aporte nutricional para ${cantidadNum}g:",
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
                    )
                    Text("Proteínas: ${(selectedComponente!!.grPro_ini * cantidadNum / 100).format(1)}g")
                    Text("Carbohidratos: ${(selectedComponente!!.grHC_ini * cantidadNum / 100).format(1)}g")
                    Text("Lípidos: ${(selectedComponente!!.grLip_ini * cantidadNum / 100).format(1)}g")
                    Text("Kcal: ${(selectedComponente!!.calculaKcal() * cantidadNum / 100).format(1)}")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cantidadNum = cantidad.toDoubleOrNull() ?: 0.0
                    when {
                        selectedComponente == null -> {
                            showError = "Debes seleccionar un componente"
                        }
                        cantidadNum <= 0 -> {
                            showError = "La cantidad debe ser mayor que 0"
                        }
                        else -> {
                            onIngredientAdded(
                                Ingrediente(
                                    componenteDietaId = componenteId,
                                    ingredienteId = selectedComponente!!.id,
                                    cantidad = cantidadNum
                                )
                            )
                        }
                    }
                },
                enabled = selectedComponente != null && cantidad.isNotEmpty()
            ) {
                Text("Añadir")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancelar")
            }
        }
    )
}

// Función de extensión para formatear números decimales
internal fun Double.format(decimals: Int): String = "%.${decimals}f".format(this) 