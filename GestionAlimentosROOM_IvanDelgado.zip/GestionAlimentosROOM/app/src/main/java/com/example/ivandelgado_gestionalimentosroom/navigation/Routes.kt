package com.example.ivandelgado_gestionalimentosroom.navigation

sealed class Routes(val route: String) {
    object Inicio : Routes("inicio")
    object ListadoDetalle : Routes("listadoDetalle")
    object Formulario : Routes("formulario/{componenteId}") {
        fun createRoute(componenteId: Int? = null) = when(componenteId) {
            null -> "formulario/nuevo"
            else -> "formulario/$componenteId"
        }
    }
    object ComponenteDetalle : Routes("componente/{componenteId}") {
        fun createRoute(componenteId: Int) = "componente/$componenteId"
    }
}